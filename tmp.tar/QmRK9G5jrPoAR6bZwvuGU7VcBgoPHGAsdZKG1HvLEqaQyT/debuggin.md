
rsync -va --exclude data.json whatsupdoc/* ../../../myOtherVault/.obsidian/plugins/whatsupdoc