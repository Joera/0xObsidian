
eligible for faucet

joera@p2p-citizen 0xB6cA51CA72C689b720235aCA37E579f821FA05EE
sad king billy 0x6974A038f0a2dC6d68Fa1c92b8d4e242FFf72f8E
memorable.eth 0x4729d7061db66Bc8EDe9d7eB5c71c5fd0a47749c
p2p-citizen 0xf0E304b7Fe717834a165D313197974634CF491F7

maar je hebt verschillende alchemy accounts nodig! 


then send all to sad king billy 

then run 
cd aa2
add amount
npx hardhat run scripts/deposit.js 


paymaster balance = 0.1837046686745945

paymaster balance = 0.1830363416795945

paymaster balance = 0.1823770852145945

paymaster balance = 0.1814228766095945